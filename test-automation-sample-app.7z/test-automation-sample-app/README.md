### Pre-requsits before start using Mobile Bank:  

1. Install Python 3.7 or Python 3.8. Remember to add python to PATH system variable during installation 
2. Execute command and check installation: 

   a. `python --version` 
   b. `pip --version`

# Installation process 

### 2. Execute command:
       git clone ssh://git@bitbucket.itgit.oneadr.net:7999/gta/test-automation-sample-app.git
### 3. Go to folder \mDoctor and execute command: 
   ``` pip install --index-url https://artifactory.itcm.oneadr.net/api/pypi/pypi-remote/simple/ -r requirements.txt ```
   This will install all dependecies please remember that file requirements.txt is in mDoctor folder
### 4. Execute command: 
   ``` python manage.py runserver ```
   
### You will see :
    Watching for file changes with StatReloader
    Performing system checks...

    System check identified no issues (0 silenced).
    April 02, 2021 - 11:38:18
    Django version 3.1.7, using settings 'mDoctor.settings'
    Starting development server at http://127.0.0.1:8000/
    Quit the server with CTRL-BREAK.

   
### Open link http://127.0.0.1:8000 You will see welcome page
    If you want use existing user login: kuba password: kubapassword
    You can create your own user :)
    ![alt text](./welcome.png)

### Have fun  