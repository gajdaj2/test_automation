from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render

# Create your views here.
from django_tables2 import RequestConfig

from doctor.models import ClientForm, Client, Account, PaymentForm, Payment, PaymentTable


@login_required
def payment(request, id_account):
    form = PaymentForm()
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cash transfer done')
    else:
        account = Account.objects.get(pk=id_account)
        client = Client.objects.get(account=account.id)
        form = PaymentForm(
            initial={'firstname': client.firstname, 'lastname': client.lastname, 'iban_sender': account.iban})
        return render(request, 'doctor/payment.html', {'form': form})
    return render(request, 'doctor/payment.html', {'form': form});


def transactions(request, id_account):
    if request.method == 'POST':
        if request.POST['check'] == 'iban':
            account_form, client = query_setup(id_account, request)
            transactions = Payment.objects.filter(client=client, iban_reciver=account_form)
            table = PaymentTable(transactions)
            RequestConfig(request, paginate={'per_page': 20}).configure(table)
            return render(request, 'doctor/transactions.html', {'table': table})
        elif request.POST['check'] == 'trx':
            account_form, client = query_setup(id_account, request)
            transactions = Payment.objects.filter(client=client, transfer_amount=account_form)
            table = PaymentTable(transactions)
            RequestConfig(request, paginate={'per_page': 20}).configure(table)
            return render(request, 'doctor/transactions.html', {'table': table})
        else:
            return transaction_operation(id_account, request)
    else:
        return transaction_operation(id_account, request)


def query_setup(id_account, request):
    account_form = request.POST['finding']
    account = Account.objects.get(pk=id_account)
    client = Client.objects.get(pk=account.id)
    return account_form, client


def transaction_operation(id_account, request):
    account = Account.objects.get(pk=id_account)
    client = Client.objects.get(pk=account.id)
    transactions = Payment.objects.filter(client=client)
    table = PaymentTable(transactions)
    RequestConfig(request, paginate={'per_page': 20}).configure(table)
    return render(request, 'doctor/transactions.html', {'table': table})


@login_required
def profile(request):
    form = ClientForm()
    if request.user.is_authenticated:
        client = Client.objects.filter(user=request.user.id).first()
        return render(request, 'doctor/profile.html', {'form': form, 'client': client})
    return render(request, 'doctor/profile.html', {'form': form})


@login_required
def landing(request):
    if request.user.is_authenticated:
        clients = Client.objects.filter(user=request.user.id)
        accounts = []
        for client in clients:
            accounts.append(Account.objects.filter(id=client.account.id).first())
        return render(request, 'website/landing.html', {"accounts": accounts})

    else:
        return render(request, 'website/login.html')


@login_required
def update(request, id):
    form = ClientForm()
    if request.method == 'POST':
        client = Client.objects.get(pk=id)
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
    else:
        client = Client.objects.get(pk=id)
        form = ClientForm(initial={'firstname': client.firstname,
                                   'lastname': client.lastname, 'address': client.address,
                                   'city': client.city})
    return render(request, 'doctor/update.html', {'client': client, 'form': form});