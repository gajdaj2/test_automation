import datetime

from django import forms
from django.contrib.auth.models import User
from django.db import models
from django.forms import ModelForm, DateInput
from django.views.generic import ListView
from django_tables2 import tables


class Account(models.Model):
    iban = models.CharField(max_length=24)
    account_balance = models.FloatField()

    def __str__(self):
        return self.iban


class Gender(models.Model):
    gender = models.CharField(max_length=4)

    def __str__(self):
        return self.gender


class Client(models.Model):
    firstname = models.CharField(max_length=200)
    lastname = models.CharField(max_length=200)
    address = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    gender = models.ForeignKey(Gender, on_delete=models.CASCADE, default=1)
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=1)

    def __str__(self):
        return self.firstname


class Payment(models.Model):
    firstname = models.CharField(max_length=200)
    lastname = models.CharField(max_length=200)
    iban_reciver = models.CharField(max_length=29)
    iban_sender = models.CharField(max_length=29)
    transfer_amount = models.FloatField()
    payment_date = models.DateTimeField()
    client = models.ForeignKey(Client, on_delete=models.CASCADE)


class PaymentForm(ModelForm):
    class Meta:
        model = Payment
        fields = ['firstname', 'lastname', 'iban_sender', 'iban_reciver', 'transfer_amount', 'payment_date', 'client']
        widgets = {
            'payment_date': DateInput(attrs={"type": "date"})
        }


class PaymentTable(tables.Table):
    class Meta:
        attrs = {"class": "table table-sm"}
        model = Payment
        exclude = {'client', 'iban_sender', 'firstname', 'lastname'}


class ClientForm(ModelForm):
    class Meta:
        model = Client
        fields = ['firstname', 'lastname', 'address', 'city', 'gender', 'account']


class AccountTable(tables.Table):
    class Meta:
        model = Account
