from django.urls import path

from doctor import views

urlpatterns = [
    path('profile/', views.profile, name='profile'),
    path('landing/', views.landing, name='landing'),
    path('update/<int:id>', views.update, name='update'),
    path('payment/<int:id_account>', views.payment, name='payment'),
    path('transactions/<int:id_account>', views.transactions, name='transactions')
]
