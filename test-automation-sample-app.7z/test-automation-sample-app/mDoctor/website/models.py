# Create your models here.
from django import forms
from django.contrib.auth.models import User
from django.forms import ModelForm, Form


class UserForm(Form):
    username = forms.CharField(max_length=200)
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    repeat_password = forms.CharField(widget=forms.PasswordInput)


