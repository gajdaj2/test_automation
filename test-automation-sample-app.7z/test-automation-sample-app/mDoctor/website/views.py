from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.forms import modelform_factory
from django.http import response
from django.shortcuts import render

# Create your views here.
from django.views.decorators.csrf import csrf_protect

from doctor.models import Client, Account
from website.models import UserForm


def index(request):
    return render(request, 'website/index.html')


user = None


@csrf_protect
def login_user(request):
    if request.method == "POST":
        username = request.POST['email']
        password = request.POST['password']
        global user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            clients = Client.objects.filter(user=request.user.id)
            accounts = []
            for client in clients:
                accounts.append(Account.objects.filter(id=client.account.id).first())
            return render(request, 'website/landing.html', {"user": user, "accounts": accounts})
        else:
            return render(request, 'website/index.html')
    elif request.method == 'GET':
        return render(request, 'website/login.html')


SignUpForm = modelform_factory(User, exclude=['is_superuser', 'is_staff', 'is_active', 'id'])


def sign_up(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            email = form.cleaned_data['email']
            User.objects.create_user(username, email, password)
            return render(request, 'website/login.html')
        else:
            return render(request, 'website/login.html')
    else:
        form = UserForm()
    return render(request, 'website/sign_up.html', {'form': form})


@login_required
def logout_user(request):
    logout(request)
    return render(request, 'website/logout.html')
