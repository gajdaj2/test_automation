from django.urls import path

import website

urlpatterns = [
    path('', website.views.index, name='index'),
    path('login/', website.views.login_user, name='login'),
    path('sign_up/',website.views.sign_up, name='sign_up'),
path('logout/',website.views.logout_user, name='logout'),
]
